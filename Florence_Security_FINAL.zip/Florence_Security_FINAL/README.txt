# Florence Security - Node.js SMTP Email Backend

This package connects the Florence Security HTML website to a real SMTP mailbox.

## 1. Install Node.js
Install Node.js LTS on the server/computer.

## 2. Install dependencies
Open Command Prompt/PowerShell in this folder:

    npm install

## 3. Configure SMTP
Open `.env` and replace:

    SMTP_HOST=YOUR_SMTP_SERVER
    SMTP_PASS=YOUR_MAILBOX_PASSWORD

Use the SMTP hostname, port, username and password supplied by the provider that hosts `info@florencesecurity.in`.

Typical settings are:
- Port 465: SMTP_SECURE=true
- Port 587: SMTP_SECURE=false

Do not put SMTP credentials in `index.html`.

## 4. Test SMTP
Start the server:

    npm start

Then open:

    http://localhost:3000/api/test-smtp

A successful response means the SMTP connection and authentication worked.

## 5. Open the website

    http://localhost:3000

Admin:
- Login ID: Florenceadmin
- Password: Florence2014
- OTP recipient: info@florencesecurity.in

The frontend calls:

    POST /api/send-email

The backend only permits delivery to ADMIN_EMAIL, so the endpoint is not an unrestricted public mail relay.

## 6. Production
For hosting, run this Node.js application with the hosting provider's Node.js application manager or a process manager such as PM2. Put the real `.env` on the server and never publish it.
