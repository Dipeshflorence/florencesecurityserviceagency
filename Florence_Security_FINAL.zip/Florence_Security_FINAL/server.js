require("dotenv").config();

const express = require("express");
const nodemailer = require("nodemailer");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const PUBLIC_DIR = path.join(__dirname, "public");

const ADMIN_EMAIL = String(process.env.ADMIN_EMAIL || "info@florencesecurity.in").trim().toLowerCase();
const SMTP_HOST = String(process.env.SMTP_HOST || "").trim();
const SMTP_PORT = Number(process.env.SMTP_PORT || 587);
const SMTP_SECURE = String(process.env.SMTP_SECURE || "false").toLowerCase() === "true";
const SMTP_USER = String(process.env.SMTP_USER || "").trim();
const SMTP_PASS = String(process.env.SMTP_PASS || "");

if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) {
  console.warn("WARNING: SMTP_HOST, SMTP_USER and SMTP_PASS are not fully configured in .env");
}

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false, limit: "1mb" }));

// Small in-memory rate limiter for this single-site backend.
// Restarting the server clears it.
const hits = new Map();
function rateLimit(req, res, next) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown")
    .split(",")[0].trim();
  const now = Date.now();
  const windowMs = 60_000;
  const max = 10;
  const item = hits.get(ip) || { start: now, count: 0 };
  if (now - item.start > windowMs) {
    item.start = now;
    item.count = 0;
  }
  item.count += 1;
  hits.set(ip, item);
  if (item.count > max) {
    return res.status(429).json({
      success: false,
      message: "Too many email requests. Please wait one minute and try again."
    });
  }
  next();
}

const transporter = nodemailer.createTransport({
  host: SMTP_HOST,
  port: SMTP_PORT,
  secure: SMTP_SECURE, // true for 465, false for 587 + STARTTLS
  auth: {
    user: SMTP_USER,
    pass: SMTP_PASS
  },
  requireTLS: !SMTP_SECURE && SMTP_PORT === 587,
  connectionTimeout: 15000,
  greetingTimeout: 15000,
  socketTimeout: 30000
});

function cleanText(value, max = 2000) {
  return String(value ?? "").replace(/\u0000/g, "").slice(0, max);
}

function fieldsToText(fields) {
  if (!fields || typeof fields !== "object") return "";
  return Object.entries(fields)
    .slice(0, 40)
    .map(([k, v]) => `${cleanText(k, 100)}: ${cleanText(v, 2000)}`)
    .join("\n");
}

app.get("/api/health", (req, res) => {
  res.json({
    success: true,
    service: "Florence Security Email Backend",
    smtpConfigured: Boolean(SMTP_HOST && SMTP_USER && SMTP_PASS),
    adminEmail: ADMIN_EMAIL
  });
});

app.get("/api/test-smtp", async (req, res) => {
  try {
    await transporter.verify();
    res.json({ success: true, message: "SMTP connection and authentication are working." });
  } catch (err) {
    console.error("SMTP VERIFY ERROR:", err);
    res.status(500).json({
      success: false,
      message: "SMTP verification failed.",
      error: err.code || err.message
    });
  }
});

app.post("/api/send-email", rateLimit, async (req, res) => {
  try {
    const to = String(req.body?.to || "").trim().toLowerCase();
    const subject = cleanText(req.body?.subject || "Florence Security Notification", 180);
    const fields = req.body?.fields || {};

    // The browser is not allowed to turn this endpoint into a general-purpose
    // mail relay. Only the configured Florence admin mailbox can receive mail.
    if (!to || to !== ADMIN_EMAIL) {
      return res.status(403).json({
        success: false,
        message: "Email recipient is not permitted."
      });
    }

    const text = fieldsToText(fields);
    const htmlRows = Object.entries(fields)
      .slice(0, 40)
      .map(([k, v]) => {
        const esc = (x) => cleanText(x, 2000)
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;")
          .replace(/"/g, "&quot;");
        return `<tr><td style="padding:7px;border:1px solid #ddd;font-weight:600">${esc(k)}</td><td style="padding:7px;border:1px solid #ddd">${esc(v)}</td></tr>`;
      }).join("");

    const info = await transporter.sendMail({
      from: `"Florence Security Website" <${SMTP_USER}>`,
      to: ADMIN_EMAIL,
      replyTo: SMTP_USER,
      subject,
      text,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:700px">
          <h2>Florence Security</h2>
          <table style="border-collapse:collapse;width:100%">${htmlRows}</table>
          <p style="font-size:12px;color:#777;margin-top:18px">
            Sent by the Florence Security website.
          </p>
        </div>
      `
    });

    res.json({
      success: true,
      message: "Email sent successfully.",
      messageId: info.messageId
    });
  } catch (err) {
    console.error("EMAIL SEND ERROR:", err);
    res.status(500).json({
      success: false,
      message: "SMTP email could not be sent.",
      error: err.code || err.message
    });
  }
});

// Static website
app.use(express.static(PUBLIC_DIR, { extensions: ["html"] }));

app.get("*", (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Florence Security server running on http://localhost:${PORT}`);
  console.log(`Admin OTP email: ${ADMIN_EMAIL}`);
});
